document.addEventListener('DOMContentLoaded', () => {
    console.log('Page loaded successfully!');
    // Add any interactive elements or event listeners here
});
